Q1 = True
Q2 = True
Q3 = False
Q4 = True
