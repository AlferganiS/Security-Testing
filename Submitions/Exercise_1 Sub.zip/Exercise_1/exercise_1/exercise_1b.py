"""
Use this file to provide your solutions for exercise 1-1 b.
"""
s1 = 'foo'
s2 = 'boo'