"""
Use this file to provide your solutions for exercise 1-1 a.
"""
s1 = 'foo'
s2 = ''