INPS = [
    '{"name": "Tron", "subject": "cybersecurity", "termsofstudying": "780", "matnr": "7009842"}',
    '{"name": "Tina", "subject": "cybersecurity", "termsofstudying": "501", "matnr": "7009844"}',
    '{"name": "Leon", "subject": "computer science", "termsofstudying": "640", "matnr": "2578921"}',
    '{"name": "Martin", "subject": "cybersecurity", "termsofstudying": "504", "matnr": "7009862"}',
    '{"name": "Josephine", "subject": "cybersecurity", "termsofstudying": "508", "matnr": "7005847"}',
    '{"name": "Don", "subject": "music", "termsofstudying": "100", "matnr": "2578542"}',
    '{"name": "Andreas", "subject": "computer science", "termsofstudying": "10000", "matnr": "2574572"}',
    '{"name": "Paul", "subject": "music", "termsofstudying": "456", "matnr": "2578533"}',
    '{"name": "Marius", "subject": "computer science", "termsofstudying": "787", "matnr": "2578922"}',
    '{"name": "Nena", "subject": "music", "termsofstudying": "786", "matnr": "2578549"}',
]
