'''
TODO:
List all the line numbers where an error occured on bf.py.
Replace the "1,2,3,4,5" with the correct line numbers.
You must list less than 7 line numbers.
'''

lines = [33,49,26,20,23]
