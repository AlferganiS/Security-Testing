import base64

if __name__ == '__main__':
    print(base64.b64decode(b'RnV6enlGdXp6').decode('utf-8'))