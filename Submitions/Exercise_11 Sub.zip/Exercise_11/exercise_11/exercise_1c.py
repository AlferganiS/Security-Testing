constraint= '''
 exists <If> f:
     exists <If> fs:
        (not inside(fs, f) and not inside(f, fs))
                
'''