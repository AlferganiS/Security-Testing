constraint= ''' 

exists <While> w:
    exists <Break> b:
        inside(b, w)
        
'''