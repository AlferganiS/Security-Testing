constraint='''
forall <FunctionDef> def:
    count(def, "<Break>", "3")
'''